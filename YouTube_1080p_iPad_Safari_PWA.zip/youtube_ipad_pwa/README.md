# YT 1080 — Descargador privado para iPad sin App Store

Esta es una adaptación del descargador original `youtube_downloader_1080p` (FastAPI + yt-dlp + FFmpeg + Deno) como **aplicación web para Safari**. El iPad no ejecuta Python: el servidor procesa vídeos y envía un MP4 al iPad. La web se puede añadir a pantalla de inicio como app (PWA). No es un `.ipa`.

> Solo para vídeos cuya descarga tengas autorizada. Las reglas de YouTube pueden restringir la obtención y el servidor puede encontrar bloqueos de IP o dificultades técnicas. Una descarga 1080p no está garantizada.

## Opción A — GitHub Codespaces desde Safari (sin PC y sin App Store)

Esta opción utiliza tu cuenta de GitHub. No necesitas una cuenta de Render. Codespaces **tiene cuotas gratuitas limitadas** en cuentas personales, pero puede tener restricciones de acceso, ejecución o facturación. Compruébalas en los ajustes de GitHub antes de usarlo. El Codespace se puede suspender cuando esté inactivo: la app no será permanente.

1. En el iPad, abre Safari y **descomprime** este ZIP en **Archivos**. No puedes ejecutar el ZIP directamente.
2. En `github.com`, crea un **repositorio privado** nuevo, por ejemplo `yt1080-ipad`. Sube los archivos descomprimidos **manteniendo exactamente la estructura** de carpetas. El código debe quedar en la raíz del repositorio (`app.py`, `Dockerfile`, `requirements.txt`, etc.); `static/` y `.devcontainer/` son subcarpetas.
   - Si la interfaz móvil no deja subir carpetas, solicita **Sitio web para ordenador** desde Safari. Puedes crear cada carpeta en GitHub con **Add file → Create new file**, escribiendo `static/.gitkeep` o `.devcontainer/.gitkeep`, y luego subir los archivos desde dentro de la carpeta; la carpeta `.devcontainer` contiene `devcontainer.json`.
3. En tu cuenta de GitHub, ve a **Settings → Codespaces → Codespaces secrets → New secret**. Crea `APP_PASSWORD` con una contraseña **única de 16 caracteres o más**, y autoriza el repositorio privado que acabas de crear. **No escribas esa contraseña en `app.py` ni la subas al repositorio.** Si ya estaba abierto un Codespace, ciérralo y vuelve a abrirlo para que el secreto esté disponible.
4. En el repositorio, pulsa **Code → Codespaces → Create codespace on main**. Se abrirá VS Code en Safari y construirá el entorno Docker (Python, Deno y FFmpeg). La compilación inicial puede tardar y consumir cuota.
5. Abre **Terminal** dentro de Codespaces y ejecuta:

   ```sh
   cd /app
   uvicorn app:app --host 0.0.0.0 --port 8000
   ```

   El secreto `APP_PASSWORD` se publica como variable de entorno de tu terminal de Codespaces. Si el servidor muestra `503`, comprueba que el secreto se haya asignado a ese repositorio y que tenga 16+ caracteres.
6. En la pestaña **Ports** de Codespaces, abre el enlace HTTPS del puerto `8000`. Asegúrate de que su visibilidad sea **Private**. Inicia sesión con tu contraseña y pega el enlace de YouTube.
7. Tras procesar el vídeo, toca **Guardar vídeo en Archivos**. Si Safari presenta el vídeo en vez de guardarlo, usa las opciones de **Compartir / Guardar en Archivos**.
8. Puedes abrir esa misma URL en **Safari → Compartir → Añadir a pantalla de inicio → Abrir como app web**, cuando esté disponible. El Codespace tendrá que permanecer activo para que funcione; al detenerlo, se suspenderá la app hasta que reanudes el Codespace y su servidor.

Guías oficiales:
- Crear Codespaces: https://docs.github.com/en/codespaces/developing-in-a-codespace/creating-a-codespace-for-a-repository
- Secretos de Codespaces: https://docs.github.com/en/codespaces/managing-your-codespaces/managing-your-account-specific-secrets-for-github-codespaces
- Abrir el puerto: https://docs.github.com/en/codespaces/developing-in-a-codespace/forwarding-ports-in-your-codespace
- Cuotas de Codespaces: https://docs.github.com/en/codespaces/troubleshooting/troubleshooting-included-usage
- App web en iPad: https://support.apple.com/guide/ipad/open-as-web-app-ipad8f1f7a29/ipados

## Opción B — Servidor HTTPS propio o proveedor de hosting compatible

El ZIP también incluye `Dockerfile` y `render.yaml` para poder desplegar en un servidor independiente y autorizado. **Comprueba previamente los requisitos de edad del proveedor y sus reglas de uso**, sin tratar de eludirlas: por ejemplo, Render prohíbe el acceso a menores de 16 años en sus términos de 2026 (https://render.com/terms).

Con un servidor Docker propio o de un administrador autorizado:

```sh
docker build -t yt-ipad-1080 .
docker run --rm -p 8000:8000 -e APP_PASSWORD='pon-una-clave-unica-de-16-caracteres' yt-ipad-1080
```

Para inicio de sesión en iPad necesitas HTTPS delante del contenedor; las cookies son `Secure`. No abras el puerto públicamente sin TLS y control de acceso. Un sitio de archivos estáticos, como GitHub Pages por sí solo, **no basta** para ejecutar el descargador.

## Características y límites

- **1080p real**, no cae a 720p silenciosamente. Si 1080p no está disponible, se informa del error.
- Límite por defecto de **30 minutos** y **300 MB** por vídeo (cambiable con `MAX_VIDEO_SECONDS` y `MAX_VIDEO_MB` en el servidor). El tope de tamaño es orientativo durante la descarga y definitivo al finalizar.
- Una descarga simultánea. Interfaz táctil con estado de descarga, acceso por contraseña y cookie de sesión.
- Archivos temporales eliminados después de entregarse o al expirar el trabajo (a los 30 minutos, siempre que el servidor siga activo); si el servicio se reinicia, los trabajos en progreso se pierden.
- Un MP4 puede contener códecs incompatibles con Fotos; `.mp4` por sí solo no garantiza H.264/AAC.
- No soporta DRM, vídeos privados ni elusión de restricciones de acceso.
- **No se ha desplegado ni probado contra YouTube real**. Se verificaron rutas de la web, login, validación de enlaces y entrega de MP4 sintética con cuatro tests. La instalación Docker y el comportamiento en Codespaces siguen pendientes de prueba en un entorno con conexión de red.

## Estructura principal

```text
app.py                     Backend privado con trabajos y borrado temporal
static/                    Interfaz para Safari, manifest e icono
tests/test_app.py           Pruebas sintéticas
.devcontainer/              Configuración de GitHub Codespaces
Dockerfile                  Python + FFmpeg + Deno
render.yaml                 Configuración opcional de hosting
requirements.txt           Dependencias Python
```
