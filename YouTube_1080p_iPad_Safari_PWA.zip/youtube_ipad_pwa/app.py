"""Private Safari/PWA frontend for authorized YouTube 1080p downloads.

Server-side yt-dlp/FFmpeg/Deno; does not execute Python on iPad.
"""
from __future__ import annotations

import hashlib
from contextlib import asynccontextmanager
import hmac
import os
import re
import secrets
import shutil
import tempfile
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from fastapi import FastAPI, Form, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.background import BackgroundTask
from yt_dlp import YoutubeDL
from yt_dlp.utils import DownloadError

BASE = Path(__file__).resolve().parent
PASSWORD = os.environ.get("APP_PASSWORD", "")
MAX_SECONDS = int(os.environ.get("MAX_VIDEO_SECONDS", "1800"))
MAX_BYTES = int(os.environ.get("MAX_VIDEO_MB", "300")) * 1024 * 1024
MAX_JOBS = 1
JOB_TTL = 30 * 60  # Delete successful downloads if not claimed.
SESSION_TTL = 7 * 24 * 60 * 60
ID_RE = re.compile(r"[A-Za-z0-9_-]{11}\Z")
@asynccontextmanager
async def lifespan(_: FastAPI):
    stop = threading.Event()

    def sweep() -> None:
        while not stop.wait(60):
            with LOCK:
                prune_jobs_locked()

    thread = threading.Thread(target=sweep, name="expired-file-cleanup", daemon=True)
    thread.start()
    try:
        yield
    finally:
        stop.set()


app = FastAPI(title="Private iPad 1080p downloader", docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)


@dataclass
class Job:
    job_id: str
    video_id: str
    created: float = field(default_factory=time.time)
    completed: float | None = None
    status: str = "working"
    stage: str = "Preparando..."
    progress: int | None = None
    error: str | None = None
    folder: Path | None = None
    output: Path | None = None
    claimed: bool = False


JOBS: dict[str, Job] = {}
LOCK = threading.RLock()
LOGIN_ATTEMPTS: dict[str, list[float]] = {}


def require_config() -> None:
    if not PASSWORD or len(PASSWORD) < 16:
        raise HTTPException(503, "Configura APP_PASSWORD (mínimo 16 caracteres) en el servidor.")


def cookie_signature(timestamp: int) -> str:
    key = hashlib.sha256(("ipad-download-session-v1:" + PASSWORD).encode()).digest()
    return hmac.new(key, str(timestamp).encode(), hashlib.sha256).hexdigest()


def is_logged_in(request: Request) -> bool:
    require_config()
    value = request.cookies.get("ipad_session", "")
    try:
        ts_text, signature = value.split(".", 1)
        ts = int(ts_text)
    except (ValueError, TypeError):
        return False
    now = int(time.time())
    if ts > now + 60 or now - ts > SESSION_TTL:
        return False
    return hmac.compare_digest(signature, cookie_signature(ts))


def require_login(request: Request) -> None:
    if not is_logged_in(request):
        raise HTTPException(401, "Sesión no iniciada")


def parse_video_id(url: str) -> str:
    parsed = urlparse(url.strip())
    if parsed.scheme not in ("https", "http") or parsed.username or parsed.password or parsed.port:
        raise ValueError("Introduce un enlace HTTP(S) de YouTube válido.")
    host = (parsed.hostname or "").lower().rstrip(".")
    parts = [x for x in parsed.path.split("/") if x]
    if host in ("youtube.com", "www.youtube.com", "m.youtube.com"):
        if parsed.path == "/watch":
            video_ids = parse_qs(parsed.query).get("v") or []
            video_id = video_ids[0] if video_ids else ""
        elif len(parts) == 2 and parts[0] in ("shorts", "live"):
            video_id = parts[1]
        else:
            raise ValueError("Pega el enlace de un vídeo concreto de YouTube.")
    elif host in ("youtu.be", "www.youtu.be") and len(parts) == 1:
        video_id = parts[0]
    else:
        raise ValueError("Solo se admiten enlaces de vídeos de YouTube.")
    if not ID_RE.fullmatch(video_id):
        raise ValueError("No se encontró un identificador de vídeo válido.")
    return video_id


def prune_jobs_locked() -> None:
    now = time.time()
    for jid, job in list(JOBS.items()):
        if job.completed and now - job.completed > JOB_TTL:
            if job.folder:
                shutil.rmtree(job.folder, ignore_errors=True)
            JOBS.pop(jid, None)


def update(job: Job, **fields: object) -> None:
    with LOCK:
        for name, value in fields.items():
            setattr(job, name, value)


def worker(job: Job) -> None:
    folder = Path(tempfile.mkdtemp(prefix="ipad_1080_"))
    update(job, folder=folder)

    def match_filter(info: dict, *, incomplete: bool = False) -> str | None:
        if info.get("is_live"):
            return "No se admiten transmisiones en directo."
        duration = info.get("duration")
        if duration and duration > MAX_SECONDS:
            return f"Este vídeo supera el límite de {MAX_SECONDS // 60} minutos."
        return None

    def progress_hook(data: dict) -> None:
        if data.get("status") == "downloading":
            size = data.get("total_bytes") or data.get("total_bytes_estimate")
            downloaded = data.get("downloaded_bytes") or 0
            pct = min(99, int(downloaded / size * 100)) if size else None
            update(job, stage="Descargando pistas de vídeo/audio...", progress=pct)
        elif data.get("status") == "finished":
            update(job, stage="Uniendo pistas en MP4...", progress=None)

    opts = {
        "format": "bv[height=1080][ext=mp4]+ba[ext=m4a]/bv[height=1080]+ba/b[height=1080]",
        "outtmpl": str(folder / f"{job.video_id}.%(ext)s"),
        "merge_output_format": "mp4",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "restrictfilenames": True,
        "retries": 2,
        "fragment_retries": 2,
        "max_filesize": MAX_BYTES,
        "match_filter": match_filter,
        "progress_hooks": [progress_hook],
    }
    try:
        if not shutil.which("ffmpeg") or not shutil.which("ffprobe") or not shutil.which("deno"):
            raise RuntimeError("El servidor necesita FFmpeg, FFprobe y Deno.")
        with YoutubeDL(opts) as ydl:
            ydl.download([f"https://www.youtube.com/watch?v={job.video_id}"])
        output = folder / f"{job.video_id}.mp4"
        if not output.is_file():
            raise RuntimeError("No se generó un MP4 compatible. Prueba otro vídeo.")
        if output.stat().st_size > MAX_BYTES:
            raise RuntimeError("El archivo supera el límite de tamaño configurado.")
        update(job, status="ready", stage="Listo para guardar", progress=100, output=output, completed=time.time())
    except DownloadError:
        shutil.rmtree(folder, ignore_errors=True)
        update(job, status="error", stage="Error", error="No se pudo obtener 1080p. Es posible que el vídeo o YouTube restrinjan la descarga, o que el servidor esté bloqueado.", completed=time.time())
    except Exception as exc:
        shutil.rmtree(folder, ignore_errors=True)
        update(job, status="error", stage="Error", error=str(exc)[:180], completed=time.time())


@app.get("/", response_class=HTMLResponse)
def homepage(request: Request):
    if is_logged_in(request):
        return FileResponse(BASE / "static" / "index.html", media_type="text/html", headers={"Cache-Control": "no-store"})
    return FileResponse(BASE / "static" / "login.html", media_type="text/html", headers={"Cache-Control": "no-store"})


@app.post("/login")
def login(request: Request, password: str = Form(...)):
    require_config()
    key = request.client.host if request.client else "unknown"
    now = time.time()
    with LOCK:
        recent = [ts for ts in LOGIN_ATTEMPTS.get(key, []) if now - ts < 300]
        if len(recent) >= 10:
            raise HTTPException(429, "Demasiados intentos. Inténtalo en unos minutos.")
        if not hmac.compare_digest(password, PASSWORD):
            LOGIN_ATTEMPTS[key] = recent + [now]
            return RedirectResponse("/?error=1", status_code=303)
        LOGIN_ATTEMPTS.pop(key, None)
    timestamp = int(now)
    reply = RedirectResponse("/", status_code=303)
    reply.set_cookie(
        "ipad_session", f"{timestamp}.{cookie_signature(timestamp)}",
        httponly=True, secure=True, samesite="strict", max_age=SESSION_TTL, path="/",
    )
    return reply


@app.post("/logout")
def logout():
    resp = RedirectResponse("/", status_code=303)
    resp.delete_cookie("ipad_session", path="/")
    return resp


@app.post("/api/jobs")
def create_job(request: Request, url: str = Form(...)):
    require_login(request)
    try:
        video_id = parse_video_id(url)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    with LOCK:
        prune_jobs_locked()
        if any(j.status == "working" for j in JOBS.values()):
            raise HTTPException(429, "Ya hay una descarga en curso. Espera a que termine.")
        job = Job(job_id=secrets.token_urlsafe(18), video_id=video_id)
        JOBS[job.job_id] = job
    thread = threading.Thread(target=worker, args=(job,), daemon=True)
    thread.start()
    return JSONResponse({"job_id": job.job_id}, status_code=202)


@app.get("/api/jobs/{job_id}")
def get_job(request: Request, job_id: str):
    require_login(request)
    with LOCK:
        prune_jobs_locked()
        job = JOBS.get(job_id)
        if not job:
            raise HTTPException(404, "Trabajo no encontrado o caducado.")
        return JSONResponse({"status": job.status, "stage": job.stage, "progress": job.progress, "error": job.error})


def cleanup_after_download(job_id: str, folder: Path) -> None:
    shutil.rmtree(folder, ignore_errors=True)
    with LOCK:
        JOBS.pop(job_id, None)


@app.get("/api/jobs/{job_id}/file")
def get_file(request: Request, job_id: str):
    require_login(request)
    with LOCK:
        job = JOBS.get(job_id)
        if not job or job.status != "ready" or not job.output or not job.folder:
            raise HTTPException(404, "El archivo aún no está disponible o ya se descargó.")
        if job.claimed:
            raise HTTPException(409, "Ya se inició la entrega del archivo.")
        job.claimed = True
        output, folder = job.output, job.folder
    return FileResponse(
        output,
        filename=f"{job.video_id}-1080p.mp4",
        media_type="video/mp4",
        headers={"Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff"},
        background=BackgroundTask(cleanup_after_download, job_id, folder),
    )


@app.get("/manifest.webmanifest")
def manifest():
    return FileResponse(BASE / "static" / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/icon.png")
def icon():
    return FileResponse(BASE / "static" / "icon.png", media_type="image/png")


@app.get("/health")
def health():
    # Do not expose private system details in an unauthenticated endpoint.
    return {"status": "ok"}


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response: Response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Cache-Control"] = response.headers.get("Cache-Control", "no-store")
    response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'"
    return response


# Public static resources only (never uploaded files or secrets).
app.mount("/assets", StaticFiles(directory=str(BASE / "static")), name="assets")
