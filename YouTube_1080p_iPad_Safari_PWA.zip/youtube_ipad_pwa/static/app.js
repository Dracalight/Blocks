const form = document.getElementById('download-form');
const input = document.getElementById('url');
const button = document.getElementById('go');
const card = document.getElementById('status-card');
const stage = document.getElementById('stage');
const detail = document.getElementById('status-detail');
const bar = document.getElementById('bar');
const file = document.getElementById('file');
let active = false;
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
async function getJson(url, opts) {
  const response = await fetch(url, {cache:'no-store', credentials:'same-origin', ...opts});
  if (response.status === 401) { location.reload(); throw new Error('Sesión caducada'); }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : `Error HTTP ${response.status}`);
  return data;
}
function showStatus(message, description, percent) {
  card.hidden = false; stage.textContent = message; detail.textContent = description;
  bar.style.width = percent == null ? '15%' : `${percent}%`;
}
form.addEventListener('submit', async event => {
  event.preventDefault(); if (active) return;
  active = true; button.disabled = true; file.hidden = true; file.removeAttribute('href');
  showStatus('Preparando…', 'Conectando con el servidor.', 5);
  try {
    const body = new FormData(); body.append('url', input.value.trim());
    const {job_id: id} = await getJson('/api/jobs', {method:'POST', body});
    for (;;) {
      const job = await getJson(`/api/jobs/${encodeURIComponent(id)}`);
      showStatus(job.stage, job.status === 'working' ? 'No cierres esta pantalla durante el procesamiento.' : '', job.progress);
      if (job.status === 'error') throw new Error(job.error || 'Descarga fallida');
      if (job.status === 'ready') {
        showStatus('¡Listo!', 'Toca el botón para descargar el MP4 y guardarlo en Archivos.', 100);
        file.href = `/api/jobs/${encodeURIComponent(id)}/file`;
        file.hidden = false;
        break;
      }
      await pause(1250);
    }
  } catch (error) { showStatus('No se pudo completar', error.message || 'Error desconocido.', 0); }
  finally { active = false; button.disabled = false; }
});
