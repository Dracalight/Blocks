if (new URLSearchParams(location.search).get('error') === '1') {
  document.getElementById('login-error').hidden = false;
}
