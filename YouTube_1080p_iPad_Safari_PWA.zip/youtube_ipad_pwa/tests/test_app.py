"""Synthetic tests: no access to YouTube is needed."""
import os
import tempfile
import time
from pathlib import Path
from unittest.mock import patch

os.environ["APP_PASSWORD"] = "a-unique-test-password-long-enough"
from fastapi.testclient import TestClient
import app as download_app

client = TestClient(download_app.app, base_url="https://testserver")


def login():
    response = client.post('/login', data={'password': os.environ['APP_PASSWORD']}, follow_redirects=False)
    assert response.status_code == 303
    assert 'Secure' in response.headers['set-cookie']


def test_static_and_login():
    response = client.get('/')
    assert response.status_code == 200
    assert 'Acceso privado' in response.text
    assert client.get('/assets/style.css').status_code == 200
    assert client.get('/assets/app.js').status_code == 200
    assert client.get('/manifest.webmanifest').status_code == 200
    assert client.get('/icon.png').status_code == 200
    assert client.get('/api/jobs/fake').status_code == 401


def test_bad_password():
    response = client.post('/login', data={'password': 'wrong'}, follow_redirects=False)
    assert response.status_code == 303 and '?error=1' in response.headers['location']


def test_url_security():
    valid = 'dQw4w9WgXcQ'
    assert download_app.parse_video_id('https://youtu.be/' + valid) == valid
    assert download_app.parse_video_id('https://www.youtube.com/watch?v=' + valid) == valid
    assert download_app.parse_video_id('https://youtube.com/shorts/' + valid) == valid
    for url in ['https://evil.com/?v=' + valid, 'https://youtube.com.evil.org/watch?v=' + valid, 'file:///etc/passwd', 'https://youtube.com/@hello', 'https://youtu.be/notvalid']:
        try:
            download_app.parse_video_id(url)
        except ValueError:
            continue
        raise AssertionError(f'Invalid URL accepted: {url}')


def test_login_job_and_download_synthetic():
    login()
    assert 'Vídeos en' in client.get('/').text
    bad = client.post('/api/jobs', data={'url':'https://evil.com'})
    assert bad.status_code == 400

    def fake_worker(job):
        folder = Path(tempfile.mkdtemp(prefix='test_1080_'))
        output = folder / (job.video_id + '.mp4')
        output.write_bytes(b'synthetic-mp4')
        download_app.update(job, folder=folder, output=output, status='ready', stage='Listo', progress=100, completed=time.time())

    with patch.object(download_app, 'worker', fake_worker):
        response = client.post('/api/jobs', data={'url':'https://youtu.be/dQw4w9WgXcQ'})
    assert response.status_code == 202
    jobid = response.json()['job_id']
    response = client.get('/api/jobs/' + jobid)
    assert response.json()['status'] == 'ready'
    response = client.get('/api/jobs/' + jobid + '/file')
    assert response.status_code == 200
    assert response.content == b'synthetic-mp4'
    assert response.headers['content-type'].startswith('video/mp4')
    assert client.get('/api/jobs/' + jobid).status_code == 404
    assert client.get('/api/jobs/' + jobid + '/file').status_code == 404
    client.post('/logout')
    assert client.get('/api/jobs/' + jobid).status_code == 401
